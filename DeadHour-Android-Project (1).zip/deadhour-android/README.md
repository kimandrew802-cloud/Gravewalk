# DEAD HOUR – offline zombie survival (Android 7.1+)

A first-person zombie survival shooter that runs 100% offline (no internet permission).
Reach the safehouse at the end of the street: hordes, special infected, four survivors,
four weapons, gore, procedural audio, and a settings menu (frame rate, graphics level,
bloom checkbox, resolution).

This folder is a ready-to-build Android Studio project. The whole game is one file:
`app/src/main/assets/index.html`, shown full-screen by a small WebView wrapper
(`MainActivity.java`). minSdk 25 = Android 7.1.

## Get the APK – pick ONE way

### A) No PC needed: GitHub builds it for you (free)
1. Create a free GitHub account and a new repository.
2. Upload every file in this folder (keep the folder structure, including `.github`).
3. Open the repo's **Actions** tab, choose **Build APK**, press **Run workflow**.
4. After ~3 minutes open the finished run, download the **DeadHour-apk** artifact, unzip it,
   and install `app-debug.apk` on your phone (allow "install unknown apps" when asked).

### B) Android Studio (Windows / Mac / Linux)
1. Install Android Studio, choose **Open**, select this folder, wait for Gradle sync.
2. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. Click **locate** – the file is `app/build/outputs/apk/debug/app-debug.apk`.

### C) Command line (needs JDK 17 + Android SDK)
    ./gradlew assembleDebug

## Game modes (Play > pick a mode > pick a map > pick a survivor)
- **Campaign** – 3 AI squadmates, reach the safehouse.
- **Single Player** – alone, thinner horde.
- **Realism** – no crosshair, no item glow, weak body shots, small medkits.
- **Versus** – 2 players, pass-and-play on one phone: each runs the map against an aggressive AI infected team; higher score wins.
- **Realism Versus** – Versus with Realism rules.
- **Survival** – hold one street against endless waves (Bronze 2:00 / Silver 4:00 / Gold 6:00).
- **Versus Survival** – pass-and-play, longest survivor wins.
- **Scavenge** – carry 8 gas cans to the generator before time runs out (SWAP drops a can; you can't shoot while carrying).
- **Mutations** – Headshot!, Bleed Out, Gib Fest, Zombie Rush, Lights Out.

## Maps
Dead Center, Dark Carnival, Swamp Fever, Hard Rain, The Parish. Original layouts and themes using these names (not Valve's levels): different sky/fog colors, lighting, wet roads, rain, props and sounds.

Versus is offline pass-and-play (no online multiplayer).

## Controls
Left thumb: move (push fully to run) · Right thumb: aim · FIRE · RELOAD · SWAP weapon ·
SHOVE · HEAL (medkit) · LIGHT (flashlight) · II pause.  Android Back button pauses.
Keyboard/mouse also work if you open `index.html` in a desktop browser:
WASD, mouse, R reload, F light, V shove, H heal, 1-4 weapons, Esc pause.

## Settings (Menu > Settings, or Pause > Settings)
Frame rate 30/45/60/90/120 · Graphics Low/Medium/High/Ultra · Bloom checkbox (checked = on) ·
Resolution 360p–1080p or Native · plus brightness, volume, sensitivity, voices, vibration, FPS counter.
If the game runs slowly: Low graphics, bloom off, 480p–540p, 30 fps.

## Notes
* Survivors are original characters (not from any existing game). Voice lines use your
  phone's built-in text-to-speech; subtitles always show. All other sounds are generated in code.
* The APK is small (a few hundred KB) because everything is generated procedurally.
* Debug APKs are signed with a debug key – fine for installing yourself.
